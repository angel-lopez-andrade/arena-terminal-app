#!/usr/bin/env sh
mkdir dist
cp -r * dist