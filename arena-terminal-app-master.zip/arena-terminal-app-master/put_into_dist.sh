#!/usr/bin/env sh
mkdir dist
cp -r index.rb helper_methods.rb Classes dist